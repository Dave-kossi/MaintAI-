"""
evaluate.py — Évaluation commune à toutes les configurations (baseline, LoRA, QLoRA).

Entrées :
  --gold : data/test.jsonl
  --pred : JSONL aligné ligne à ligne avec le gold ; chaque ligne contient
           {"texte": ..., "sortie_brute": "<texte généré par le modèle>"}

Métriques :
  - json_valide      : part des sorties lisibles et conformes au schéma
  - P / R / F1 micro : par champ et global (correspondance exacte après
                       minuscules + normalisation des espaces)
  - global_micro_ic95: intervalle de confiance à 95 % du F1 global (bootstrap
                       sur les textes du test, 1 000 rééchantillonnages)
  - taux_inventions  : part des éléments prédits absents du texte source
  - exact_match      : part des textes entièrement corrects

Usage :
  python evaluate.py --gold data/test.jsonl --pred results/lora05.jsonl --out results/lora05_metrics.json
"""

import argparse
import json
import random
import re

FIELDS = ["equipements", "symptomes", "actions", "proprietes"]


def norm(s) -> str:
    return re.sub(r"\s+", " ", str(s).strip().lower())


def parse_output(raw):
    """Extrait le premier objet JSON de la sortie du modèle. Renvoie None si invalide."""
    if isinstance(raw, dict):
        obj = raw
    else:
        m = re.search(r"\{.*\}", raw or "", flags=re.DOTALL)
        if not m:
            return None
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            return None
    if not isinstance(obj, dict):
        return None
    for f in FIELDS:
        v = obj.get(f, [])
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            return None
    return obj


def load_jsonl(path):
    with open(path, encoding="utf-8") as fh:
        return [json.loads(l) for l in fh if l.strip()]


def per_example(gold, preds):
    """Comptes par texte : base de toutes les métriques, du bootstrap et des comparaisons."""
    assert len(gold) == len(preds), (
        f"gold ({len(gold)} lignes) et pred ({len(preds)} lignes) doivent avoir la même taille")
    rows = []
    for g, p in zip(gold, preds):
        obj = parse_output(p.get("sortie_brute", ""))
        valid = obj is not None
        if not valid:
            obj = {f: [] for f in FIELDS}  # JSON invalide = rien de prédit
        texte = norm(g["texte"])
        row = {"valid": valid, "exact": valid, "n_pred": 0, "n_inv": 0}
        for f in FIELDS:
            gs = {norm(x) for x in g[f]}
            ps = {norm(x) for x in obj.get(f, [])}
            row[f] = (len(gs & ps), len(ps - gs), len(gs - ps))  # tp, fp, fn
            row["exact"] = row["exact"] and gs == ps
            row["n_pred"] += len(ps)
            row["n_inv"] += sum(1 for x in ps if x not in texte)
        rows.append(row)
    return rows


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return {"precision": round(p, 4), "rappel": round(r, 4), "f1": round(f, 4)}


def global_f1(rows):
    tp = sum(r[f][0] for r in rows for f in FIELDS)
    fp = sum(r[f][1] for r in rows for f in FIELDS)
    fn = sum(r[f][2] for r in rows for f in FIELDS)
    return prf(tp, fp, fn)["f1"]


def bootstrap_ci(rows, n_boot=1000, seed=0):
    rng = random.Random(seed)
    n = len(rows)
    vals = sorted(global_f1([rows[rng.randrange(n)] for _ in range(n)]) for _ in range(n_boot))
    return [round(vals[int(0.025 * n_boot)], 4), round(vals[int(0.975 * n_boot) - 1], 4)]


def aggregate(rows, n_boot=1000):
    n = len(rows)
    n_pred = sum(r["n_pred"] for r in rows)
    res = {
        "n": n,
        "json_valide": round(sum(r["valid"] for r in rows) / n, 4),
        "exact_match": round(sum(r["exact"] for r in rows) / n, 4),
        "taux_inventions": round(sum(r["n_inv"] for r in rows) / n_pred, 4) if n_pred else 0.0,
        "par_champ": {f: prf(sum(r[f][0] for r in rows), sum(r[f][1] for r in rows),
                             sum(r[f][2] for r in rows)) for f in FIELDS},
    }
    tp = sum(r[f][0] for r in rows for f in FIELDS)
    fp = sum(r[f][1] for r in rows for f in FIELDS)
    fn = sum(r[f][2] for r in rows for f in FIELDS)
    res["global_micro"] = prf(tp, fp, fn)
    res["global_micro_ic95"] = bootstrap_ci(rows, n_boot) if n_boot else None
    return res


def evaluate(gold, preds, n_boot=1000):
    return aggregate(per_example(gold, preds), n_boot)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", required=True)
    ap.add_argument("--pred", required=True)
    ap.add_argument("--out")
    ap.add_argument("--bootstrap", type=int, default=1000)
    args = ap.parse_args()
    res = evaluate(load_jsonl(args.gold), load_jsonl(args.pred), args.bootstrap)
    print(json.dumps(res, indent=2, ensure_ascii=False))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
