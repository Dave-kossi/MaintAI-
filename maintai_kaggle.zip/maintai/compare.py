"""
compare.py — L'amélioration apportée par LoRA est-elle réelle ou due au hasard ?

Bootstrap apparié : on rééchantillonne les MÊMES textes du test pour les deux
configurations, puis on regarde la distribution de la différence de F1 global.
Si l'intervalle à 95 % ne contient pas 0, la différence est significative.

Usage :
  python compare.py                       # paires par défaut (voir PAIRS)
  python compare.py --pairs base05_fs:lora05 lora05:lora15
Sortie : results/comparaisons.csv
"""

import argparse
import csv
import random
from pathlib import Path

from evaluate import global_f1, load_jsonl, per_example

# (référence, configuration testée) : « avant » puis « après »
PAIRS = [
    ("base05_zs", "lora05"), ("base05_fs", "lora05"),
    ("base15_zs", "lora15"), ("base15_fs", "lora15"),
    ("lora05", "lora15"), ("base15_fs", "lora05"), ("lora15", "qlora15"),
]


def paired_bootstrap(rows_a, rows_b, n_boot=2000, seed=0):
    rng = random.Random(seed)
    n = len(rows_a)
    diffs = []
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        diffs.append(global_f1([rows_b[i] for i in idx]) - global_f1([rows_a[i] for i in idx]))
    diffs.sort()
    p_two_sided = 2 * min(sum(d <= 0 for d in diffs), sum(d >= 0 for d in diffs)) / n_boot
    return diffs[int(0.025 * n_boot)], diffs[int(0.975 * n_boot) - 1], min(p_two_sided, 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", default="data/test.jsonl")
    ap.add_argument("--results", default="results")
    ap.add_argument("--pairs", nargs="*", help="paires ref:config, ex. base05_fs:lora05")
    ap.add_argument("--out", default="results/comparaisons.csv")
    args = ap.parse_args()

    pairs = [tuple(p.split(":")) for p in args.pairs] if args.pairs else PAIRS
    gold = load_jsonl(args.gold)
    cache, out = {}, []

    def rows(name):
        if name not in cache:
            path = Path(args.results) / f"{name}.jsonl"
            cache[name] = per_example(gold, load_jsonl(path)) if path.exists() else None
        return cache[name]

    for a, b in pairs:
        ra, rb = rows(a), rows(b)
        if ra is None or rb is None:
            continue
        lo, hi, p = paired_bootstrap(ra, rb)
        f1a, f1b = global_f1(ra), global_f1(rb)
        out.append({"reference": a, "configuration": b, "F1_reference": round(f1a, 4),
                    "F1_configuration": round(f1b, 4), "difference": round(f1b - f1a, 4),
                    "ic95_bas": round(lo, 4), "ic95_haut": round(hi, 4), "p_valeur": round(p, 4),
                    "significatif": "oui" if lo > 0 or hi < 0 else "non"})

    if not out:
        print("Aucune paire disponible dans", args.results)
        return
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    for r in out:
        print(f"{r['reference']:>10} -> {r['configuration']:<8} ΔF1 = {r['difference']:+.3f} "
              f"[{r['ic95_bas']:+.3f} ; {r['ic95_haut']:+.3f}]  p = {r['p_valeur']:.3f}  "
              f"significatif : {r['significatif']}")
    print(f"\nTableau : {args.out}")


if __name__ == "__main__":
    main()
