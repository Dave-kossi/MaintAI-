"""
train_lora.py — Adaptation légère (LoRA ou QLoRA) d'un petit LLM sur MaintIE.

Seuls les adaptateurs LoRA sont entraînés ; les poids du modèle de base restent gelés.
La perte n'est calculée que sur la réponse JSON (pas sur le prompt).

Installation (Colab / Kaggle) :
  pip install -q "transformers>=4.44" "peft>=0.12" accelerate bitsandbytes

Exemples :
  python train_lora.py --model Qwen/Qwen2.5-0.5B-Instruct --out runs/lora05
  python train_lora.py --model Qwen/Qwen2.5-1.5B-Instruct --out runs/lora15
  python train_lora.py --model Qwen/Qwen2.5-1.5B-Instruct --qlora --out runs/qlora15

Sortie : l'adaptateur dans --out, et --out/train_stats.json (paramètres entraînés,
temps d'entraînement, mémoire GPU max, pertes) pour l'analyse « avantages et limites ».
"""

import argparse
import json
import math
import random
import time

import torch
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from torch.utils.data import DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, get_cosine_schedule_with_warmup

from infer import build_messages, target_json, load_jsonl


def encode(rec, tok, max_len):
    """Prompt (sans exemples few-shot) + réponse ; labels = -100 sur le prompt."""
    msgs = build_messages(rec["texte"], [])
    prompt = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    answer = target_json(rec) + tok.eos_token
    p_ids = tok(prompt, add_special_tokens=False)["input_ids"]
    a_ids = tok(answer, add_special_tokens=False)["input_ids"]
    ids = (p_ids + a_ids)[:max_len]
    labels = ([-100] * len(p_ids) + a_ids)[:max_len]
    return {"input_ids": ids, "labels": labels}


def collate(batch, pad_id):
    L = max(len(b["input_ids"]) for b in batch)
    ids = torch.full((len(batch), L), pad_id)
    lab = torch.full((len(batch), L), -100)
    att = torch.zeros((len(batch), L), dtype=torch.long)
    for i, b in enumerate(batch):
        n = len(b["input_ids"])
        ids[i, :n] = torch.tensor(b["input_ids"])
        lab[i, :n] = torch.tensor(b["labels"])
        att[i, :n] = 1
    return {"input_ids": ids, "labels": lab, "attention_mask": att}


@torch.no_grad()
def eval_loss(model, loader):
    model.eval()
    tot, n = 0.0, 0
    for batch in loader:
        batch = {k: v.to(model.device) for k, v in batch.items()}
        tot += model(**batch).loss.item()
        n += 1
    model.train()
    return tot / max(n, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--qlora", action="store_true", help="modèle de base quantifié en 4 bits (QLoRA)")
    ap.add_argument("--train", default="data/train.jsonl")
    ap.add_argument("--val", default="data/val.jsonl")
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--alpha", type=int, default=32)
    ap.add_argument("--dropout", type=float, default=0.05)
    ap.add_argument("--max-len", type=int, default=384)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--limit", type=int, default=None, help="test rapide sur N exemples")
    args = ap.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    tok = AutoTokenizer.from_pretrained(args.model)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    if args.qlora:
        from transformers import BitsAndBytesConfig
        bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                 bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        model = AutoModelForCausalLM.from_pretrained(args.model, quantization_config=bnb, device_map="auto")
        model = prepare_model_for_kbit_training(model)
    else:
        # LoRA : base gelée en fp16 ; les adaptateurs sont passés en fp32 plus bas
        model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.float16, device_map="auto")
        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()

    cfg = LoraConfig(r=args.rank, lora_alpha=args.alpha, lora_dropout=args.dropout, bias="none",
                     task_type="CAUSAL_LM",
                     target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                                     "gate_proj", "up_proj", "down_proj"])
    model = get_peft_model(model, cfg)
    for p in model.parameters():  # adaptateurs en fp32 pour un entraînement stable en fp16
        if p.requires_grad:
            p.data = p.data.float()
    # compteur PEFT : il corrige le comptage des poids 4 bits (QLoRA), sinon le total serait sous-estimé
    trainable, total = model.get_nb_trainable_parameters()
    model.print_trainable_parameters()

    train = [encode(r, tok, args.max_len) for r in load_jsonl(args.train)[: args.limit]]
    val = [encode(r, tok, args.max_len) for r in load_jsonl(args.val)]
    col = lambda b: collate(b, tok.pad_token_id)
    tl = DataLoader(train, batch_size=args.batch, shuffle=True, collate_fn=col)
    vl = DataLoader(val, batch_size=args.batch, collate_fn=col)

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr)
    steps = args.epochs * len(tl)
    sched = get_cosine_schedule_with_warmup(opt, int(0.05 * steps), steps)
    scaler = torch.amp.GradScaler("cuda", enabled=torch.cuda.is_available())

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    t0, history, best = time.time(), [], math.inf
    model.train()
    for ep in range(args.epochs):
        run = 0.0
        for step, batch in enumerate(tl):
            batch = {k: v.to(model.device) for k, v in batch.items()}
            with torch.autocast("cuda", dtype=torch.float16, enabled=torch.cuda.is_available()):
                loss = model(**batch).loss
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            scaler.step(opt)
            scaler.update()
            opt.zero_grad(set_to_none=True)
            sched.step()
            run += loss.item()
            if (step + 1) % 20 == 0:
                print(f"epoch {ep+1} step {step+1}/{len(tl)} loss {run/(step+1):.4f}")
        vloss = eval_loss(model, vl)
        history.append({"epoch": ep + 1, "train_loss": round(run / len(tl), 4), "val_loss": round(vloss, 4)})
        print(history[-1])
        if vloss < best:  # on garde le meilleur epoch selon la perte de validation
            best = vloss
            model.save_pretrained(args.out)
            tok.save_pretrained(args.out)

    stats = {
        "model": args.model, "methode": "QLoRA" if args.qlora else "LoRA",
        "rank": args.rank, "alpha": args.alpha, "lr": args.lr, "epochs": args.epochs, "batch": args.batch,
        "n_train": len(train),
        "params_entraines": trainable, "params_total": total,
        "pct_entraines": round(100 * trainable / total, 3),
        "temps_entrainement_min": round((time.time() - t0) / 60, 2),
        "memoire_gpu_max_go": round(torch.cuda.max_memory_allocated() / 1e9, 3) if torch.cuda.is_available() else None,
        "historique": history, "meilleure_val_loss": round(best, 4),
    }
    with open(f"{args.out}/train_stats.json", "w") as fh:
        json.dump(stats, fh, indent=2)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
