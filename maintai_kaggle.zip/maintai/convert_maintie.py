"""
convert_maintie.py — Conversion du corpus MaintIE vers le schéma JSON MaintAI
et création des splits train / val / test (80/10/10, figés par une graine).

Format MaintIE (une liste d'enregistrements) :
{
  "tokens":   ["engine", "oil", "blender", "running", "constantly"],
  "entities": [{"start": 2, "end": 3, "type": "PhysicalObject/MatterProcessingObject/MixingObject"}, ...],
  "relations": [{"type": "hasPart", "head": 1, "tail": 3}, ...]
}
- "end" est exclusif ; "type" est hiérarchique (on garde le niveau 1).
- Le corpus "coarse" n'a que les 5 classes de niveau 1 : le script gère les deux.

Schéma cible MaintAI (v1) :
{
  "texte": "engine oil blender running constantly",
  "equipements": [...],   # PhysicalObject
  "symptomes":   [...],   # State + Process
  "actions":     [...],   # Activity
  "proprietes":  [...]    # Property
}
"résultat" et "cause" ne sont pas annotés dans MaintIE : ils ne font pas partie
de la vérité terrain ni de l'évaluation chiffrée.

Données : https://github.com/nlp-tlp/maintie (licence MIT)
  data/gold_release.json   -> corpus fin, 1 076 textes (vérité terrain)
  data/silver_release.json -> corpus grossier, 7 000 textes (entraînement optionnel)

Usage :
  git clone https://github.com/nlp-tlp/maintie.git
  python convert_maintie.py --input maintie/data/gold_release.json --outdir data/ --seed 42
"""

import argparse
import json
import random
from collections import Counter
from pathlib import Path

CLASS_TO_FIELD = {
    "PhysicalObject": "equipements",
    "State": "symptomes",
    "Process": "symptomes",
    "Activity": "actions",
    "Property": "proprietes",
}
FIELDS = ["equipements", "symptomes", "actions", "proprietes"]


def convert_record(rec: dict, spans: str = "maximal") -> dict:
    """spans="maximal" : pour les entités imbriquées d'un même champ
    ("fault", "power fault", "low power fault"), on ne garde que la plus longue.
    spans="all" : on garde toutes les mentions distinctes."""
    tokens = rec["tokens"]
    # On reconstruit le texte depuis les tokens : chaque mention est alors
    # garantie d'être une sous-chaîne du texte (utile pour détecter les inventions).
    out = {"texte": " ".join(tokens)}
    ranges = {f: [] for f in FIELDS}
    for ent in rec.get("entities", []):
        field = CLASS_TO_FIELD.get(ent["type"].split("/")[0])
        if field is not None:
            ranges[field].append((ent["start"], ent["end"]))
    for f in FIELDS:
        rs = sorted(set(ranges[f]))
        if spans == "maximal":
            rs = [r for r in rs
                  if not any(o != r and o[0] <= r[0] and r[1] <= o[1] for o in rs)]
        out[f] = []
        for s, e in rs:
            span = " ".join(tokens[s:e])
            if span not in out[f]:
                out[f].append(span)
    return out


def load(path: Path) -> list:
    with open(path, encoding="utf-8") as fh:
        text = fh.read().strip()
    if text.startswith("["):
        return json.loads(text)
    return [json.loads(line) for line in text.splitlines() if line.strip()]  # JSONL


def dump(records: list, path: Path) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        for r in records:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, type=Path)
    ap.add_argument("--outdir", default=Path("data"), type=Path)
    ap.add_argument("--seed", default=42, type=int)
    ap.add_argument("--spans", choices=["maximal", "all"], default="maximal")
    args = ap.parse_args()

    raw = load(args.input)
    data = [convert_record(r, args.spans) for r in raw]

    # Doublons de texte : on n'en garde qu'un pour éviter les fuites train/test
    seen, unique = set(), []
    for d in data:
        if d["texte"] not in seen:
            seen.add(d["texte"])
            unique.append(d)

    random.Random(args.seed).shuffle(unique)
    n = len(unique)
    n_train, n_val = int(0.8 * n), int(0.1 * n)
    splits = {
        "train": unique[:n_train],
        "val": unique[n_train:n_train + n_val],
        "test": unique[n_train + n_val:],
    }

    args.outdir.mkdir(parents=True, exist_ok=True)
    for name, recs in splits.items():
        dump(recs, args.outdir / f"{name}.jsonl")

    # Statistiques descriptives (pour le rapport)
    print(f"Enregistrements lus : {len(raw)} | après dédoublonnage : {n}")
    for name, recs in splits.items():
        counts = Counter({f: sum(len(r[f]) for r in recs) for f in FIELDS})
        print(f"{name:5s} : {len(recs):5d} textes | " +
              " | ".join(f"{f}={counts[f]}" for f in FIELDS))
    lengths = [len(d["texte"].split()) for d in unique]
    print(f"Longueur moyenne : {sum(lengths)/n:.1f} tokens (max {max(lengths)})")


if __name__ == "__main__":
    main()
