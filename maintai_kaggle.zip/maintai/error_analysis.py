"""
error_analysis.py — Classe automatiquement chaque erreur des modèles, pour l'analyse qualitative.

Catégories (une erreur = un élément en trop ou en moins dans un champ) :
  json_invalide  : la sortie n'est pas un JSON exploitable (compté une fois par texte)
  masque_extrait : le modèle a extrait un masque d'anonymisation (<id>, <num>, ...)
  mauvais_champ  : élément correct mais rangé dans le mauvais champ
  frontiere      : bon élément mais découpé trop court ou trop long (« pump » vs « water pump »)
  invention      : élément absent du texte (hallucination)
  faux_positif   : élément présent dans le texte mais non annoté à cet endroit
  oubli          : élément annoté que le modèle n'a pas extrait

Sorties :
  results/erreurs_resume.csv          : nombre d'erreurs par configuration et par catégorie
  results/erreurs_<config>.csv        : chaque erreur avec son texte, à lire pour le rapport

Usage : python error_analysis.py            (toutes les configurations trouvées dans results/)
        python error_analysis.py --configs base05_fs lora05
"""

import argparse
import csv
import re
from collections import Counter
from pathlib import Path

from evaluate import FIELDS, load_jsonl, norm, parse_output

CATEGORIES = ["json_invalide", "masque_extrait", "mauvais_champ", "frontiere",
              "invention", "faux_positif", "oubli"]
MASK = re.compile(r"^<[^<>]+>$")
ORDER = ["base05_zs", "base05_fs", "lora05", "base15_zs", "base15_fs", "lora15", "qlora15"]


def overlaps(a, b):
    return a != b and (a in b or b in a)


def classify(gold_rec, raw):
    """Liste des erreurs d'un texte : (categorie, champ, element)."""
    obj = parse_output(raw)
    if obj is None:
        return [("json_invalide", "-", (raw or "").strip()[:120])]
    texte = norm(gold_rec["texte"])
    g = {f: {norm(x) for x in gold_rec[f]} for f in FIELDS}
    p = {f: {norm(x) for x in obj.get(f, [])} for f in FIELDS}
    errs = []
    for f in FIELDS:
        others_gold = set().union(*(g[o] for o in FIELDS if o != f))
        others_pred = set().union(*(p[o] for o in FIELDS if o != f))
        for x in sorted(p[f] - g[f]):  # éléments en trop
            if MASK.match(x):
                cat = "masque_extrait"
            elif x in others_gold:
                cat = "mauvais_champ"
            elif x not in texte:
                cat = "invention"
            elif any(overlaps(x, y) for y in g[f]):
                cat = "frontiere"
            else:
                cat = "faux_positif"
            errs.append((cat, f, x))
        for y in sorted(g[f] - p[f]):  # éléments manquants
            if y in others_pred or any(overlaps(y, x) for x in p[f]):
                continue  # déjà compté comme mauvais_champ ou frontiere
            errs.append(("oubli", f, y))
    return errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", default="data/test.jsonl")
    ap.add_argument("--results", default="results")
    ap.add_argument("--configs", nargs="*")
    args = ap.parse_args()

    gold = load_jsonl(args.gold)
    res = Path(args.results)
    configs = args.configs or [c for c in ORDER if (res / f"{c}.jsonl").exists()]
    summary = []
    for c in configs:
        preds = load_jsonl(res / f"{c}.jsonl")
        if len(preds) != len(gold):
            print(f"{c} : {len(preds)} prédictions pour {len(gold)} textes, ignoré")
            continue
        counts, lines = Counter(), []
        for g, pr in zip(gold, preds):
            raw = pr.get("sortie_brute", "")
            for cat, f, x in classify(g, raw):
                counts[cat] += 1
                lines.append({"categorie": cat, "champ": f, "element": x, "texte": g["texte"],
                              "attendu": "; ".join(f"{k}={g[k]}" for k in FIELDS if g[k]),
                              "sortie_modele": raw.strip().replace("\n", " ")[:300]})
        lines.sort(key=lambda r: (CATEGORIES.index(r["categorie"]), r["texte"]))
        with open(res / f"erreurs_{c}.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["categorie", "champ", "element", "texte",
                                               "attendu", "sortie_modele"])
            w.writeheader()
            w.writerows(lines)
        summary.append({"configuration": c, **{k: counts[k] for k in CATEGORIES},
                        "total": sum(counts.values())})

    if not summary:
        print("Aucune configuration à analyser.")
        return
    with open(res / "erreurs_resume.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["configuration"] + CATEGORIES + ["total"])
        w.writeheader()
        w.writerows(summary)
    head = f"{'configuration':<12}" + "".join(f"{k[:12]:>14}" for k in CATEGORIES) + f"{'total':>8}"
    print(head)
    for s in summary:
        print(f"{s['configuration']:<12}" + "".join(f"{s[k]:>14}" for k in CATEGORIES) + f"{s['total']:>8}")
    print(f"\nRésumé : {res / 'erreurs_resume.csv'} ; détail : {res}/erreurs_<config>.csv")


if __name__ == "__main__":
    main()
