"""
summarize.py — Rassemble toutes les expériences dans un seul tableau comparatif.

Lit, pour chaque configuration <nom> :
  results/<nom>_metrics.json   (evaluate.py)
  results/<nom>.jsonl.perf.json (infer.py : latence, mémoire en inférence)
  runs/<run>/train_stats.json   (train_lora.py, si la configuration est adaptée)

Usage : python summarize.py --out results/tableau.csv
"""

import argparse
import csv
import json
from pathlib import Path

# nom de la configuration -> dossier d'entraînement (None = pas d'adaptation)
CONFIGS = {
    "base05_zs": None, "base05_fs": None, "lora05": "runs/lora05",
    "base15_zs": None, "base15_fs": None, "lora15": "runs/lora15", "qlora15": "runs/qlora15",
}


def read(path):
    p = Path(path)
    return json.loads(p.read_text()) if p.exists() else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/tableau.csv")
    args = ap.parse_args()

    rows = []
    for name, run in CONFIGS.items():
        m = read(f"results/{name}_metrics.json")
        if m is None:
            continue
        perf = read(f"results/{name}.jsonl.perf.json") or {}
        tr = read(f"{run}/train_stats.json") if run else None
        row = {
            "configuration": name,
            "F1_global": m["global_micro"]["f1"],
            "F1_ic95_bas": (m.get("global_micro_ic95") or [None, None])[0],
            "F1_ic95_haut": (m.get("global_micro_ic95") or [None, None])[1],
            "precision": m["global_micro"]["precision"],
            "rappel": m["global_micro"]["rappel"],
            **{f"F1_{k}": v["f1"] for k, v in m["par_champ"].items()},
            "JSON_valide": m["json_valide"],
            "inventions": m["taux_inventions"],
            "exact_match": m["exact_match"],
            "latence_s": perf.get("latence_moyenne_s"),
            "mem_inference_Go": perf.get("memoire_gpu_max_go"),
            "pct_params_entraines": tr["pct_entraines"] if tr else 0,
            "temps_entrainement_min": tr["temps_entrainement_min"] if tr else 0,
            "mem_entrainement_Go": tr["memoire_gpu_max_go"] if tr else None,
        }
        rows.append(row)

    if not rows:
        print("Aucun résultat trouvé dans results/.")
        return
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    cols = ["configuration", "F1_global", "JSON_valide", "inventions", "latence_s",
            "pct_params_entraines", "temps_entrainement_min", "mem_entrainement_Go"]
    print(" | ".join(cols))
    for r in rows:
        print(" | ".join(str(r[c]) for c in cols))
    print(f"\nTableau complet : {args.out}")


if __name__ == "__main__":
    main()
