"""
make_figures.py — Figures du rapport, à partir des sorties des autres scripts.

  figures/fig1_f1_global.png      F1 global par modèle et par méthode, avec IC à 95 %
  figures/fig2_f1_par_champ.png   F1 par champ, avant / après adaptation
  figures/fig3_couts.png          temps d'entraînement et mémoire GPU (deux panneaux, pas de double axe)
  figures/fig4_pertes.png         courbes de perte (entraînement et validation) par adaptation
  figures/fig5_erreurs.png        répartition des erreurs par catégorie

Usage : python make_figures.py   (lit results/ et runs/, écrit figures/)
"""

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

RES, RUNS, OUT = Path("results"), Path("runs"), Path("figures")

# Palette catégorielle validée (ordre fixe : une méthode garde toujours sa couleur)
COLORS = {"Zero-shot": "#2a78d6", "Few-shot (5)": "#eb6834", "LoRA": "#1baf7a", "QLoRA": "#6250d6"}
INK, INK2, GRID, SURFACE = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
MODELS = {"05": "Qwen2.5-0.5B", "15": "Qwen2.5-1.5B"}
METHODS = {"Zero-shot": "base{m}_zs", "Few-shot (5)": "base{m}_fs", "LoRA": "lora{m}", "QLoRA": "qlora{m}"}
FIELDS = {"equipements": "Équipements", "symptomes": "Symptômes", "actions": "Actions",
          "proprietes": "Propriétés"}

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "legend.frameon": False, "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
})


def read_json(p):
    return json.loads(p.read_text()) if p.exists() else None


def metrics(name):
    return read_json(RES / f"{name}_metrics.json")


def n_test():
    for p in sorted(RES.glob("*_metrics.json")):
        return read_json(p)["n"]
    return 0


def save(fig, name):
    OUT.mkdir(exist_ok=True)
    fig.savefig(OUT / name, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("figure :", OUT / name)


def grouped_bars(ax, groups, series, values, errs=None, fmt="{:.2f}"):
    """Barres groupées, fines, 2 px d'écart, valeur écrite au-dessus de chaque barre."""
    n = len(series)
    width = 0.8 / max(n, 1)
    for j, s in enumerate(series):
        xs = [i + (j - (n - 1) / 2) * width for i in range(len(groups))]
        ys = [values[s][i] for i in range(len(groups))]
        keep = [k for k, y in enumerate(ys) if y is not None]
        if not keep:
            continue
        ax.bar([xs[k] for k in keep], [ys[k] for k in keep], width * 0.92, color=COLORS.get(s),
               label=s, edgecolor=SURFACE, linewidth=1)
        if errs:
            for k in keep:
                e = errs[s][k]
                if e:
                    ax.errorbar(xs[k], ys[k], yerr=[[ys[k] - e[0]], [e[1] - ys[k]]], color=INK2,
                                capsize=3, linewidth=1)
        for k in keep:
            top = errs[s][k][1] if errs and errs[s][k] else ys[k]
            ax.text(xs[k], top + 0.015, fmt.format(ys[k]), ha="center", va="bottom", fontsize=8, color=INK)
    ax.set_xticks(range(len(groups)), groups)
    ax.grid(axis="x", visible=False)


def fig1():
    groups, vals, errs = [], {m: [] for m in METHODS}, {m: [] for m in METHODS}
    for code, label in MODELS.items():
        found = False
        for meth, pat in METHODS.items():
            m = metrics(pat.format(m=code))
            vals[meth].append(m["global_micro"]["f1"] if m else None)
            errs[meth].append(m.get("global_micro_ic95") if m else None)
            found = found or m is not None
        groups.append(label if found else None)
    keep = [i for i, g in enumerate(groups) if g]
    if not keep:
        return
    groups = [groups[i] for i in keep]
    series = [s for s in METHODS if any(vals[s][i] is not None for i in keep)]
    vals = {s: [vals[s][i] for i in keep] for s in series}
    errs = {s: [errs[s][i] for i in keep] for s in series}
    fig, ax = plt.subplots(figsize=(7, 4))
    grouped_bars(ax, groups, series, vals, errs)
    ax.set_ylim(0, 1.08)
    ax.set_ylabel(f"F1 global (micro), test de {n_test()} textes")
    ax.set_title("F1 global avant et après adaptation", pad=24)
    ax.legend(ncol=len(series), loc="upper left", bbox_to_anchor=(0, -0.08))
    ax.text(0, 1.025, "Barres d'erreur : intervalle de confiance à 95 % (bootstrap)", transform=ax.transAxes,
            fontsize=8, color=INK2)
    save(fig, "fig1_f1_global.png")


def fig2():
    configs = []
    for code, label in MODELS.items():
        for meth in ("Few-shot (5)", "LoRA"):
            name = METHODS[meth].format(m=code)
            m = metrics(name)
            if m:
                configs.append((f"{label} · {meth}", m))
    if not configs:
        return
    fig, axes = plt.subplots(1, len(MODELS), figsize=(10, 4.2), sharey=True)
    axes = axes if hasattr(axes, "__len__") else [axes]
    for ax, (code, label) in zip(axes, MODELS.items()):
        series = []
        vals = {}
        for meth in ("Few-shot (5)", "LoRA"):
            m = metrics(METHODS[meth].format(m=code))
            if m:
                series.append(meth)
                vals[meth] = [m["par_champ"][f]["f1"] for f in FIELDS]
        if not series:
            ax.set_visible(False)
            continue
        grouped_bars(ax, list(FIELDS.values()), series, vals)
        ax.tick_params(axis="x", labelsize=9)
        ax.set_title(label)
        ax.set_ylim(0, 1.1)
    axes[0].set_ylabel("F1 sur le test")
    handles, labels = [], []
    for ax in axes:
        for h, l in zip(*ax.get_legend_handles_labels()):
            if l not in labels:
                handles.append(h)
                labels.append(l)
    fig.legend(handles, labels, loc="lower left", ncol=len(labels), bbox_to_anchor=(0.06, -0.06))
    fig.subplots_adjust(top=0.78, wspace=0.08)
    fig.suptitle("F1 par champ : few-shot contre LoRA", x=0.06, y=0.99, ha="left", fontweight="bold")
    fig.text(0.06, 0.905, "Le F1 des propriétés repose sur 8 éléments seulement dans le test", fontsize=8,
             color=INK2)
    save(fig, "fig2_f1_par_champ.png")


def fig3():
    runs = []
    for code, label in MODELS.items():
        for meth in ("LoRA", "QLoRA"):
            st = read_json(RUNS / METHODS[meth].format(m=code) / "train_stats.json")
            if st:
                runs.append((f"{label}\n{meth}", meth, st))
    if not runs:
        return
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(9, 3.4))
    for ax, key, title, unit in ((a1, "temps_entrainement_min", "Temps d'entraînement", "minutes"),
                                 (a2, "memoire_gpu_max_go", "Mémoire GPU maximale", "Go")):
        ys = [r[2].get(key) or 0 for r in runs]
        ax.barh(range(len(runs)), ys, 0.55, color=[COLORS[r[1]] for r in runs], edgecolor=SURFACE)
        ax.set_yticks(range(len(runs)), [r[0] for r in runs])
        ax.invert_yaxis()
        ax.set_title(title)
        ax.set_xlabel(unit)
        ax.grid(axis="y", visible=False)
        for i, y in enumerate(ys):
            ax.text(y, i, f" {y:.1f}", va="center", fontsize=8, color=INK)
        ax.set_xlim(0, max(ys + [1e-9]) * 1.25)
    a2.set_yticklabels([])
    pct = ", ".join(f"{r[0].replace(chr(10), ' ')} : {r[2]['pct_entraines']} %" for r in runs)
    fig.text(0.02, -0.12, f"Part des paramètres entraînés : {pct}", fontsize=8, color=INK2)
    save(fig, "fig3_couts.png")


def fig4():
    runs = [(f"{MODELS[c]} · {meth}", read_json(RUNS / METHODS[meth].format(m=c) / "train_stats.json"))
            for c in MODELS for meth in ("LoRA", "QLoRA")]
    runs = [(n, s) for n, s in runs if s and s.get("historique")]
    if not runs:
        return
    fig, axes = plt.subplots(1, len(runs), figsize=(3.2 * len(runs), 3), sharey=True, squeeze=False)
    for ax, (name, st) in zip(axes[0], runs):
        ep = [h["epoch"] for h in st["historique"]]
        ax.plot(ep, [h["train_loss"] for h in st["historique"]], color="#2a78d6", linewidth=2,
                marker="o", markersize=5, label="Entraînement")
        ax.plot(ep, [h["val_loss"] for h in st["historique"]], color="#eb6834", linewidth=2,
                marker="o", markersize=5, label="Validation")
        ax.set_title(name, fontsize=10)
        ax.set_xlabel("epoch")
        ax.set_xticks(ep)
    axes[0][0].set_ylabel("perte (entropie croisée)")
    axes[0][0].legend(loc="upper right")
    save(fig, "fig4_pertes.png")


def fig5():
    p = RES / "erreurs_resume.csv"
    if not p.exists():
        return
    rows = list(csv.DictReader(open(p, encoding="utf-8")))
    cats = [c for c in ["json_invalide", "masque_extrait", "mauvais_champ", "frontiere", "invention",
                        "faux_positif", "oubli"] if any(int(r[c]) for r in rows)]
    if not cats:
        return
    palette = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"]
    labels = {"json_invalide": "JSON invalide", "masque_extrait": "Masque extrait",
              "mauvais_champ": "Mauvais champ", "frontiere": "Frontière", "invention": "Invention",
              "faux_positif": "Faux positif", "oubli": "Oubli"}
    fig, ax = plt.subplots(figsize=(8, 0.55 * len(rows) + 1.6))
    left = [0] * len(rows)
    for k, c in enumerate(cats):
        v = [int(r[c]) for r in rows]
        ax.barh(range(len(rows)), v, 0.6, left=left, color=palette[k], label=labels[c],
                edgecolor=SURFACE, linewidth=2)
        left = [a + b for a, b in zip(left, v)]
    for i, tot in enumerate(left):
        ax.text(tot, i, f" {tot}", va="center", fontsize=8, color=INK)
    ax.set_yticks(range(len(rows)), [r["configuration"] for r in rows])
    ax.invert_yaxis()
    ax.grid(axis="y", visible=False)
    ax.set_xlabel(f"nombre d'erreurs sur les {n_test()} textes du test")
    ax.set_title("Nature des erreurs par configuration")
    ax.legend(ncol=4, loc="upper left", bbox_to_anchor=(0, -0.18), fontsize=8)
    save(fig, "fig5_erreurs.png")


if __name__ == "__main__":
    for f in (fig1, fig2, fig3, fig4, fig5):
        f()
