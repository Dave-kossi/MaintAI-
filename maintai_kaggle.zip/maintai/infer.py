"""
infer.py — Génération des prédictions MaintAI (baseline OU modèle adapté LoRA/QLoRA).

Le même script sert pour toutes les configurations, ce qui garantit une
comparaison équitable : même prompt, même décodage, même jeu de test.

Exemples (Colab / Kaggle, GPU T4) :
  # Baseline zero-shot
  python infer.py --model Qwen/Qwen2.5-0.5B-Instruct --shots 0 --out results/base05_zs.jsonl
  # Baseline few-shot (5 exemples tirés du train)
  python infer.py --model Qwen/Qwen2.5-0.5B-Instruct --shots 5 --out results/base05_fs.jsonl
  # Modèle adapté LoRA (zero-shot : le modèle a appris le format)
  python infer.py --model Qwen/Qwen2.5-0.5B-Instruct --adapter runs/lora05 --shots 0 --out results/lora05.jsonl

Sortie : un JSONL aligné sur test.jsonl, lisible par evaluate.py, + un fichier
<out>.perf.json (latence moyenne par texte, mémoire GPU maximale).
"""

import argparse
import json
import random
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

FIELDS = ["equipements", "symptomes", "actions", "proprietes"]

SYSTEM_PROMPT = (
    "You extract structured information from short industrial maintenance work orders. "
    "Return ONLY a JSON object with exactly these keys: "
    '"equipements" (physical objects: equipment, parts, components), '
    '"symptomes" (undesirable states or processes: failures, leaks, damage), '
    '"actions" (maintenance activities: replace, inspect, repair...), '
    '"proprietes" (properties such as pressure, temperature, crack). '
    "Each value is a list of exact text spans copied from the input. "
    "Use [] when nothing applies. Never invent information that is not in the text. "
    "Tokens such as <id>, <num>, <date>, <sensitive> are masks: never extract them."
)


def target_json(rec: dict) -> str:
    return json.dumps({f: rec[f] for f in FIELDS}, ensure_ascii=False)


def build_messages(text: str, examples: list) -> list:
    msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
    for ex in examples:
        msgs.append({"role": "user", "content": ex["texte"]})
        msgs.append({"role": "assistant", "content": target_json(ex)})
    msgs.append({"role": "user", "content": text})
    return msgs


def load_jsonl(path):
    with open(path, encoding="utf-8") as fh:
        return [json.loads(l) for l in fh if l.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--adapter", default=None, help="dossier d'un adaptateur PEFT (LoRA/QLoRA)")
    ap.add_argument("--load-4bit", action="store_true", help="charger le modèle de base en 4 bits (QLoRA)")
    ap.add_argument("--test", default="data/test.jsonl")
    ap.add_argument("--train", default="data/train.jsonl")
    ap.add_argument("--shots", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--max-new-tokens", type=int, default=160)
    ap.add_argument("--limit", type=int, default=None, help="pour un test rapide sur N textes")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    test = load_jsonl(args.test)[: args.limit]
    examples = []
    if args.shots:
        # exemples fixes (graine) et non vides, pour un few-shot reproductible
        pool = [r for r in load_jsonl(args.train) if r["symptomes"] and r["actions"]]
        examples = random.Random(args.seed).sample(pool, args.shots)

    tok = AutoTokenizer.from_pretrained(args.model)
    kwargs = {"device_map": "auto", "torch_dtype": torch.float16}  # T4 : pas de bf16
    if args.load_4bit:
        from transformers import BitsAndBytesConfig
        kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
    model = AutoModelForCausalLM.from_pretrained(args.model, **kwargs)
    if args.adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, args.adapter)
    model.eval()

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    latencies = []
    with open(args.out, "w", encoding="utf-8") as fh:
        for i, rec in enumerate(test):
            prompt = tok.apply_chat_template(build_messages(rec["texte"], examples),
                                             tokenize=False, add_generation_prompt=True)
            inputs = tok(prompt, return_tensors="pt").to(model.device)
            t0 = time.perf_counter()
            with torch.no_grad():
                out = model.generate(**inputs, max_new_tokens=args.max_new_tokens,
                                     do_sample=False, pad_token_id=tok.eos_token_id)
            latencies.append(time.perf_counter() - t0)
            gen = tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
            fh.write(json.dumps({"texte": rec["texte"], "sortie_brute": gen}, ensure_ascii=False) + "\n")
            if i < 3 or (i + 1) % 20 == 0:
                print(f"[{i+1}/{len(test)}] {rec['texte']!r} -> {gen.strip()[:150]}")

    perf = {
        "model": args.model, "adapter": args.adapter, "shots": args.shots, "load_4bit": args.load_4bit,
        "n": len(test),
        "latence_moyenne_s": round(sum(latencies) / len(latencies), 4),
        "memoire_gpu_max_go": round(torch.cuda.max_memory_allocated() / 1e9, 3) if torch.cuda.is_available() else None,
    }
    with open(args.out + ".perf.json", "w") as fh:
        json.dump(perf, fh, indent=2)
    print(json.dumps(perf, indent=2))


if __name__ == "__main__":
    main()
